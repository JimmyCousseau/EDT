public class Utils {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";

    // retrun a random integer contain in [min; max]
    public static int getRandomIntInRange(int min, int max) {
        assert min < max;
        return (int)(Math.random()*(max-min+1) + min);
    }

    public static int rollADice() { return getRandomIntInRange(1, 6); }

    public static void sleep(int timeInMillisec) {
        try {
            Thread.sleep(timeInMillisec);
        } catch (InterruptedException e) {}
    }
}
