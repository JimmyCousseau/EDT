public class Map {
    // Variables de la classe Map
    private final int MAP_WIDTH = 5; // Largeur du plateau
    private final int MAP_HEIGHT = 5; // Hauteur du plateau
    private final int NUMBER_OF_P = 4; // Nombre de joueurs dans la partie, celui-ci doit-être strictement égal au nombre véritable
    private final int NUMBER_OF_EQUIPE = 5; // Nombre d'équipe dans le jeu, celui-ci doit-être supérieur ou égal au nombre véritable
    private char[][] plateau = new char[MAP_WIDTH][MAP_HEIGHT];
    private Personnage[] p = new Personnage[NUMBER_OF_P];

    // Constructeur
    Map() {
        p[0] = new Personnage(new Position(0, 0), 0, "Cavalier", 'C', 1, 4, 4, 2, 2, 3, this);
        p[1] = new Personnage(new Position(1, 1), 1, "Cavalier", 'D', 1, 4, 4, 2, 2, 1, this);
        p[2] = new Personnage(new Position(1, 0), 1, "Cavalier", 'D', 1, 4, 4, 2, 2, 1, this);
        p[3] = new Personnage(new Position(0, 1), 1, "Cavalier", 'D', 1, 4, 4, 2, 2, 1, this);
    
    }

    void updateMap() {
        int x, y;

        for (int i = 0; i < MAP_HEIGHT; i++) {
            for (int j = 0; j < MAP_WIDTH; j++) {
                plateau[j][i] = '.';
            }
        }
        for (int i = 0; i < NUMBER_OF_P; i++) {
            if (p[i].getVie() > 0) {
                x = p[i].getPosition().getX();
                y = p[i].getPosition().getY();
                plateau[x][y] = p[i].getSymbol();
            }
        }
    }

    void drawMap() {
        hatPlateau();

        for (int i = 0; i < MAP_HEIGHT; i++) {
            for (int j = 0; j < MAP_WIDTH; j++) {
                if (j == 0) {
                    System.out.print("\n|");
                }

                System.out.print(plateau[j][i] + " ");
                if (j == MAP_WIDTH - 1) {
                    System.out.print("|");
                }
            }
        }
        
        hatPlateau();
        System.out.println();
    }

    void hatPlateau() { // Draw the top and the bottom of the board
        System.out.print("\n+");
        for (int i = 0; i < MAP_WIDTH; i++) {
            System.out.print("- ");
        }
        System.out.print("+");
    }

    void mouv() {
        for (int i = 0; i < NUMBER_OF_P; i++) {
            if (p[i].getVie() > 0) {
                p[i].Deplacement(p);
            }
        }
    }

    // Getters 
    public int getNumberOfP() { return NUMBER_OF_P; }
    public Personnage[] getPersons() { return p; }
    public int getNumberOfEquipe() { return NUMBER_OF_EQUIPE; }
    public int getMapHeight() { return MAP_HEIGHT; }
    public int getMapWidth() { return MAP_WIDTH; }
}
