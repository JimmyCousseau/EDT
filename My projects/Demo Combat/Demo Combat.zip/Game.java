import java.util.Scanner;

public class Game {
    private boolean run = true;
    private boolean fastMode;
    private boolean firstLaunch = true;
    private Map map = new Map();
    private int[] NbPAlived = new int[map.getNumberOfEquipe()];
    private int NbEquipeAlived;

    public void GameRun() {
        while (run) {
            if (firstLaunch) {
                Scanner enter = new Scanner(System.in);
                System.out.println("Voulez-vous une démo instantannée ou pas à pas ? 1 : Oui, 0 : Non");
                fastMode = enter.nextBoolean();
                firstLaunch = false;
                enter.close();
                Map map = new Map();
                map.updateMap();
                map.drawMap();
            } else {
                if (fastMode) {
                    do {
                        map.mouv();
                        map.updateMap();
                        map.drawMap();
                        // Remise des compteurs à 0
                        NbEquipeAlived = map.getNumberOfEquipe();
                        for (int i = 0; i < map.getNumberOfEquipe(); i++) {
                            NbPAlived[i] = 0;
                        }

                        // Compte le nombre de survivants dans chaques équipes
                        for (int i = 0; i < map.getNumberOfP(); i++) {
                            if (map.getPersons()[i].getVie() > 0) {
                                NbPAlived[map.getPersons()[i].getEquipe()] += 1;
                            }
                        }

                        // Compte le nombre d'équipes survivantes
                        for (int i = 0; i < map.getNumberOfEquipe(); i++) {
                            if (NbPAlived[i] == 0) {
                                NbEquipeAlived--;
                            }
                        }
                    } while (NbEquipeAlived > 1);
                    System.out.println("La partie est terminée");
                    run = false;
                } else {
                    do {
                        map.mouv();
                        map.updateMap();
                        map.drawMap();
                        Scanner enter = new Scanner(System.in);
                        System.out.println("Voulez-vous continuer la démo ? 1 : Oui, 0 : Non");
                        run = enter.nextBoolean();
                        enter.close();
                    } while (run);
                }
            }
        }
    }
}
