public class Position{
    // Variables de la classe position
    private int x;
    private int y;

    // Constructeur
    Position(int x, int y) {
        this.x = x;
        this.y = y;
    }


    // Getters
    public int getX() { return x; }
    public int getY() { return y; }
    
    // Setters
    void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }
    

}
